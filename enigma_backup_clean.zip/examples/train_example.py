from enigma.core.training import train_model

if __name__ == "__main__":
    train_model(force=True, num_epochs=5)
