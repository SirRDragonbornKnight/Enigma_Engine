"""
Device Discovery for Enigma Network

Automatically find other Enigma nodes on the local network.
Uses multiple discovery methods:
  1. mDNS/Zeroconf (if available)
  2. UDP broadcast
  3. Manual IP scanning
"""

import json
import socket
import threading
import time
from typing import Dict, List, Callable, Optional


class DeviceDiscovery:
    """
    Discover other Enigma nodes on the network.
    """
    
    BROADCAST_PORT = 5001
    DISCOVERY_MESSAGE = b"ENIGMA_DISCOVER"
    RESPONSE_PREFIX = b"ENIGMA_NODE:"
    
    def __init__(self, node_name: str, node_port: int = 5000):
        """
        Args:
            node_name: Name of this node
            node_port: Port this node's API is on
        """
        self.node_name = node_name
        self.node_port = node_port
        
        # Discovered devices: {name: {"ip": ..., "port": ..., "last_seen": ...}}
        self.discovered: Dict[str, Dict] = {}
        
        # Discovery callbacks
        self._on_discover: List[Callable] = []
        
        # Listener thread
        self._listener_thread = None
        self._running = False
    
    def on_discover(self, callback: Callable[[str, Dict], None]):
        """
        Register a callback for when a device is discovered.
        
        callback(name, info) will be called.
        """
        self._on_discover.append(callback)
    
    def _notify_discover(self, name: str, info: Dict):
        """Notify all callbacks of a discovery."""
        for cb in self._on_discover:
            try:
                cb(name, info)
            except:
                pass
    
    def get_local_ip(self) -> str:
        """Get this machine's local IP address."""
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except:
            return "127.0.0.1"
    
    def start_listener(self):
        """Start listening for discovery broadcasts."""
        if self._running:
            return
        
        self._running = True
        self._listener_thread = threading.Thread(target=self._listen_loop, daemon=True)
        self._listener_thread.start()
        print(f"Discovery listener started on port {self.BROADCAST_PORT}")
    
    def stop_listener(self):
        """Stop the discovery listener."""
        self._running = False
    
    def _listen_loop(self):
        """Main listener loop."""
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        sock.settimeout(1.0)
        
        try:
            sock.bind(("", self.BROADCAST_PORT))
        except OSError as e:
            print(f"Could not bind to port {self.BROADCAST_PORT}: {e}")
            return
        
        while self._running:
            try:
                data, addr = sock.recvfrom(1024)
                
                if data == self.DISCOVERY_MESSAGE:
                    # Someone is looking for nodes - respond
                    response = self.RESPONSE_PREFIX + json.dumps({
                        "name": self.node_name,
                        "port": self.node_port,
                    }).encode()
                    sock.sendto(response, addr)
                    
                elif data.startswith(self.RESPONSE_PREFIX):
                    # Got a response from another node
                    info_json = data[len(self.RESPONSE_PREFIX):]
                    try:
                        info = json.loads(info_json.decode())
                        name = info.get("name", "unknown")
                        
                        if name != self.node_name:  # Don't discover ourselves
                            device_info = {
                                "ip": addr[0],
                                "port": info.get("port", 5000),
                                "last_seen": time.time(),
                            }
                            
                            is_new = name not in self.discovered
                            self.discovered[name] = device_info
                            
                            if is_new:
                                print(f"Discovered node: {name} at {addr[0]}:{device_info['port']}")
                                self._notify_discover(name, device_info)
                    except:
                        pass
                        
            except socket.timeout:
                pass
            except Exception as e:
                if self._running:
                    print(f"Discovery error: {e}")
        
        sock.close()
    
    def broadcast_discover(self, timeout: float = 3.0) -> Dict[str, Dict]:
        """
        Send a discovery broadcast and collect responses.
        
        Args:
            timeout: How long to wait for responses
            
        Returns:
            Dict of discovered devices
        """
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        sock.settimeout(0.5)
        
        # Send broadcast
        try:
            sock.sendto(self.DISCOVERY_MESSAGE, ("<broadcast>", self.BROADCAST_PORT))
        except:
            # Try specific broadcast address
            local_ip = self.get_local_ip()
            if "." in local_ip:
                parts = local_ip.split(".")
                broadcast = f"{parts[0]}.{parts[1]}.{parts[2]}.255"
                sock.sendto(self.DISCOVERY_MESSAGE, (broadcast, self.BROADCAST_PORT))
        
        # Collect responses
        start_time = time.time()
        while time.time() - start_time < timeout:
            try:
                data, addr = sock.recvfrom(1024)
                
                if data.startswith(self.RESPONSE_PREFIX):
                    info_json = data[len(self.RESPONSE_PREFIX):]
                    try:
                        info = json.loads(info_json.decode())
                        name = info.get("name", "unknown")
                        
                        if name != self.node_name:
                            self.discovered[name] = {
                                "ip": addr[0],
                                "port": info.get("port", 5000),
                                "last_seen": time.time(),
                            }
                    except:
                        pass
            except socket.timeout:
                pass
        
        sock.close()
        return self.discovered
    
    def scan_network(
        self,
        port: int = 5000,
        subnet: str = None,
        timeout: float = 0.5
    ) -> Dict[str, Dict]:
        """
        Scan the local network for Enigma nodes.
        
        Args:
            port: Port to check for Enigma API
            subnet: Subnet to scan (e.g., "192.168.1"). If None, auto-detect
            timeout: Timeout per host
            
        Returns:
            Dict of discovered devices
        """
        import urllib.request
        
        if subnet is None:
            local_ip = self.get_local_ip()
            parts = local_ip.split(".")
            subnet = f"{parts[0]}.{parts[1]}.{parts[2]}"
        
        print(f"Scanning {subnet}.0/24 for Enigma nodes...")
        
        def check_host(ip):
            try:
                url = f"http://{ip}:{port}/info"
                req = urllib.request.Request(url)
                with urllib.request.urlopen(req, timeout=timeout) as response:
                    data = json.loads(response.read().decode())
                    name = data.get("name", "unknown")
                    if name != self.node_name:
                        return name, {
                            "ip": ip,
                            "port": port,
                            "last_seen": time.time(),
                            "model": data.get("model"),
                        }
            except:
                pass
            return None, None
        
        # Scan in parallel using threads
        results = []
        threads = []
        
        for i in range(1, 255):
            ip = f"{subnet}.{i}"
            t = threading.Thread(target=lambda ip=ip: results.append(check_host(ip)))
            t.start()
            threads.append(t)
            
            # Limit concurrent threads
            if len(threads) >= 50:
                for t in threads:
                    t.join()
                threads = []
        
        # Wait for remaining threads
        for t in threads:
            t.join()
        
        # Process results
        for name, info in results:
            if name and info:
                self.discovered[name] = info
                print(f"Found: {name} at {info['ip']}:{info['port']}")
        
        return self.discovered
    
    def get_device_url(self, name: str) -> Optional[str]:
        """Get the URL for a discovered device."""
        if name in self.discovered:
            info = self.discovered[name]
            return f"http://{info['ip']}:{info['port']}"
        return None


# Convenience function
def discover_enigma_nodes(node_name: str = "scanner", timeout: float = 3.0) -> Dict[str, Dict]:
    """
    Quick function to discover Enigma nodes on the network.
    
    Args:
        node_name: Name for this scanner (to avoid self-discovery)
        timeout: How long to wait for responses
        
    Returns:
        Dict of discovered devices
    """
    discovery = DeviceDiscovery(node_name)
    return discovery.broadcast_discover(timeout)


if __name__ == "__main__":
    print("Scanning for Enigma nodes...")
    nodes = discover_enigma_nodes()
    
    if nodes:
        print(f"\nFound {len(nodes)} node(s):")
        for name, info in nodes.items():
            print(f"  {name}: {info['ip']}:{info['port']}")
    else:
        print("No nodes found. Make sure other Enigma instances are running with discovery enabled.")
